keep digging
